# Shades

This Chrome extension simulates the effects of the sunglasses from the 1988 classic sci-fi horror [They Live](http://www.imdb.com/title/tt0096256/). At the moment it only works on [BBC News](http://www.bbc.co.uk/news).

## Installation

